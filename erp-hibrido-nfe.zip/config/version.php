<?php
function appVersion(): string
{
    if (!function_exists('shell_exec')) {
        return 'unknown';
    }

    $version = shell_exec('git describe --tags --abbrev=0 2>/dev/null');

    return $version ? trim($version) : 'dev';
}

define('APP_VERSION', appVersion());

?>